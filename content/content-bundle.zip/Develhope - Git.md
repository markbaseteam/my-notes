---
quickshare-date: "N/A"
quickshare-url: "Removed"
---
Git is a version control system which allows us to save our work and changes to our code and collaborate with other developers as well

#### <u style="color:#F96767;">References & Resources</u>
- [Git Official Documentation](https://git-scm.com/doc)
- <b>Git Cheat-Sheet Websites:</b>
	- [Git cheat-sheet](https://git-hint.netlify.app/)
	- [Another Git cheat-sheet](https://training.github.com/downloads/github-git-cheat-sheet/)
- [How to Write Good Commit Messages: A Practical Git Guide](https://www.freecodecamp.org/news/writing-good-commit-messages-a-practical-guide/)
- [Bitbucket Git educational resource](https://www.atlassian.com/git/tutorials)
- [Learn Git branching](https://learngitbranching.js.org/?locale=eng)
- [Github flow](https://docs.github.com/en/get-started/quickstart/github-flow)
- [Github Handbook](https://guides.github.com/introduction/git-handbook/)
- [Github Learning Lab](https://lab.github.com/)
- [Comparing Workflows](https://www.atlassian.com/git/tutorials/comparing-workflows)
### <u style="color:#6DF053;">Version Control System (VCS)</u>
 - Save our work
	 - first commit (timestamp)
	 - "secnd feature added" (timestamp) -> *When commiting new code, this will tell us what changes have done in the code this will help to let developers know what the issue was*
	 - third feature added (timestamp) -> *Bug happened here*

- Revert back to any previous save
- Automatically keep a detailed history of your work
- It is also great because, after a developer have committed a code, it lets other developers know who committed the code on *Github* and be able to ask about the code if there is any issues not understanding a part of the committed code
- Easily collaborate and share code of others (Because of VC, it keeps track of large history of code features added or removed, know exactly what have been added when, work seamlessly with other developers) 
- Merge different pieces of code together
- branch out and experiment. Experimental branches help us to have a safe environment to code in and not mess anything with the main branch and experiment with what we want, check for bugs and correct them if any does rise, keep detailed history with the changes that we have done  
	- Main branch:
		- first commit (timestamp)
		- "secnd feature added" (timestamp)
		- third feature added (timestamp) -> *Bug happened here*
	
	*// The new branch is used for experimentation, once you are done experimenting you can merge the new branch with the main branch
	- New Branch:
		- third feature
		- new commit
		- new commit two
### <u style="color:#6DF053;">GIT</u>
- git is a version control system
- command line tool 
	- visual alternatives available
- available across platfroms
- platfomrs: github, gitlab, bitbucket

- git workflow:
	- write some code
	- add that code to git
	- commit the added code
	- push our code to the server
### <u style="color:#6DF053;">Git config</u>
- `git --help` -> list some commands to use in various situations
- `git help -a`-> list all of the commands
### <u style="color:#6DF053;">Git init</u>
-  `git init` command creates a new Git repository. It can be used to convert an existing, unversioned project to a Git repository or initialize a new, empty repository.
### <u style="color:#6DF053;">Git clone</u>
- `git clone` is a Git command line utility which is used to target an existing repository and create a clone, or copy of the target repository.
### <u style="color:#6DF053;">Git add and commit</u>
- `git commit` Create a new commit containing the current contents of the index and the given log message describing the changes. The new commit is a direct child of HEAD, usually the tip of the current branch, and the branch is updated to point to it (unless no branch is associated with the working tree, in which case HEAD is "detached"
- `git add` updates the index using the current content found in the working tree, to prepare the content staged for the next commit. It typically adds the current content of existing paths as a whole, but with some options it can also be used to add content with only part of the changes made to the working tree files applied, or remove paths that do not exist in the working tree anymore.

- Steps before pushing code to github:
	- write some code (working code)
	- add that code to git (staging area)
	- commit the added code (make a new version)
	- push our code to the server

- `git status` displays paths that have differences between the index file and the current HEAD commit, paths that have differences between the working tree and the index file, and paths in the working tree that are not tracked by Git (and are not ignored by [gitignore[5]](https://git-scm.com/docs/gitignore)).
### <u style="color:#6DF053;">Git log</u>
- `git log`  shows commit logs -> List commits that are reachable by following the `parent` links from the given commit(s), but exclude commits that are reachable from the one(s) given with a _^_ in front of them. The output is given in reverse chronological order by default.
### <u style="color:#6DF053;">Git diff</u>
- `git diff` show changes between the working tree and the index or a tree, changes between the index and a tree, changes between two trees, changes resulting from a merge, changes between two blob objects, or changes between two files on disk.
### <u style="color:#6DF053;">Git branch</u>
- `git branch` - List, create, or delete branches -> If `--list` is given, or if there are no non-option arguments, existing branches are listed; the current branch will be highlighted in green and marked with an asterisk.
- When creating another branch, for example, `main` and `sub_main` branches. If a file is created in `sub_main` branch, added then commited, no effect the main branch will occur, or any other branches if do exist and it will not show up then the branches when typing the command `ls -la` to list all files
- <b>SYNOPSIS</b>
	```shell
	git branch [--color[=<when>] | --no-color] [--show-current]
			[-v [--abbrev=<n> | --no-abbrev]]
			[--column[=<options>] | --no-column] [--sort=<key>]
			[--merged [<commit>]] [--no-merged [<commit>]]
			[--contains [<commit>]] [--no-contains [<commit>]]
			[--points-at <object>] [--format=<format>]
			[(-r | --remotes) | (-a | --all)]
			[--list] [<pattern>…]

	git branch [--track[=(direct|inherit)] | --no-track] [-f]
	        [--recurse-submodules] <branchname> [<start-point>]

	git branch (--set-upstream-to=<upstream> | -u <upstream>) [<branchname>]
	git branch --unset-upstream [<branchname>]
	git branch (-m | -M) [<oldbranch>] <newbranch>
	git branch (-c | -C) [<oldbranch>] <newbranch>
	git branch (-d | -D) [-r] <branchname>…
	git branch --edit-description [<branchname>]
	```
### <u style="color:#6DF053;">Git checkout</u>
- `git checkout` - Switch branches or restore working tree files
- <b>SYNOPSIS</b>
	```shell
	git checkout [-q] [-f] [-m] [<branch>]
	git checkout [-q] [-f] [-m] --detach [<branch>]
	git checkout [-q] [-f] [-m] [--detach] <commit>
	git checkout [-q] [-f] [-m] [[-b|-B|--orphan] <new-branch>] [<start-point>]
	git checkout [-f|--ours|--theirs|-m|--conflict=<style>] [<tree-ish>] [--] <pathspec>…
	git checkout [-f|--ours|--theirs|-m|--conflict=<style>] [<tree-ish>] --pathspec-from-file=<file> [--pathspec-file-nul]
	git checkout (-p|--patch) [<tree-ish>] [--] [<pathspec>…]
	```
- `git checkout .` is used to to checkout to the previous changes (revert back any changes to the default state) of the branch and remove any changes that have been done 
	- <u>Another explanation:</u> With **both branch and path specifiers** (`git checkout branch .`) it writes content in specified revision. It will _not_ modify where `HEAD` points, so if `branch` is different from `HEAD`, there will be unstaged changes afterwards.
- When there is a bug or a change you need to change or fix to a commit, you could get the log generated id of that specific commit from `git log` and then type `git checkout <commit_id>` . This will put you in an experimental mode with no `HEAD` and a message will be displayed such as this:
 ```git
  Note: switching to '38c9984e37f4f41de75a70a1fd6107982e8e8bef'.

  You are in 'detached HEAD' state. You can look around, make experimental
  changes and commit them, and you can discard any commits you make in this
  state without impacting any branches by switching back to a branch.

  If you want to create a new branch to retain commits you create, you may
  do so (now or later) by using -c with the switch command. Example:

  git switch -c <new-branch-name>

  Or undo this operation with:

  git switch -

  Turn off this advice by setting config variable advice.detachedHead to false

  HEAD is now at 38c9984 change READEME.md
 ```
 - `git switch` <b>SYNOPSIS</b>
  ```git
    _git switch_ [<options>] [--no-guess] <branch>
	_git switch_ [<options>] --detach [<start-point>]
	_git switch_ [<options>] (-c|-C) <new-branch> [<start-point>]
	_git switch_ [<options>] --orphan <new-branch>
  ```
### <u style="color:#6DF053;">Git HEAD</u>
- When working with Git, only _one_ branch can be checked out at a time - and this is what's called the `HEAD` branch. Often, this is also referred to as the "active" or "current" branch.
- In rare cases, the HEAD file does NOT contain a branch reference, but a SHA-1 value of a specific revision. This happens when you checkout a specific commit, tag, or remote branch. Your repository is then in a state called [Detached HEAD](https://www.git-tower.com/learn/git/faq/detached-head-when-checkout-commit).
### <u style="color:#6DF053;">Git restore</u>
- `git restore` is a tool to revert non-commited changes. Non-commited changes are: a) changes in your working copy, or b) content in your index (a.k.a. staging area) -> let you discard changes in a working directory.
- <b>SYNOPSIS</b>
 ```shell
 git restore [<options>] [--source=<tree>] [--staged] [--worktree] [--] <pathspec>…
 git restore [<options>] [--source=<tree>] [--staged] [--worktree] --pathspec-from-file=<file> [--pathspec-file-nul]
 git restore (-p|--patch) [<options>] [--source=<tree>] [--staged] [--worktree] [--] [<pathspec>…]
 ```
- git-restore can be used in three different modes, depending on whether you like to revert work in the working copy, in the index, or both.
	- `git restore [--worktree] <file>` overwrites `<file>` in your working copy with the contents in your index (*). In other words, it reverts your changes in the working copy. Whether you specify `--worktree` or not does not matter because it is implied if you don't say otherwise.
	-  `git restore --staged <file>` overwrites `<file>` in your index with the current HEAD from the local repository. In other words, it unstages previously staged content. In so far, it is indeed equivalent to the old `git reset HEAD <file>`.
	- To overwrite both, the working copy and the index with the current HEAD, use `git restore --staged --worktree --source HEAD <file>`. This version does both: revert your working copy to HEAD and unstage previously staged work.
### <u style="color:#6DF053;">Git reset</u>
- `git reset` - Reset current HEAD to the specified state. You can use git reset to rewind history without changing the contents of your local files -> (`Git reset` is the command we use when we want to move the repository back to a previous commit, discarding any changes made after that commit) [Git Reset explanation](https://www.w3schools.com/git/git_reset.asp?remote=github)
- **SYNOPSIS**
 ```shell
 git reset [-q] [<tree-ish>] [--] <pathspec>…
 git reset [-q] [--pathspec-from-file=<file> [--pathspec-file-nul]] [<tree-ish>]
 git reset (--patch | -p) [<tree-ish>] [--] [<pathspec>…]
 git reset [--soft | --mixed [-N] | --hard | --merge | --keep] [-q] [<commit>]
 ```
### <u style="color:#6DF053;">Git revert</u>
- `git revert` command can be considered an 'undo' type command, however, it is not a traditional undo operation. Instead of removing the commit from the project history, it figures out how to invert the changes introduced by the commit and appends a new commit with the resulting inverse content. This prevents Git from losing history, which is important for the integrity of your revision history and for reliable collaboration.
- Reverting should be used when you want to apply the inverse of a commit from your project history. This can be useful, for example, if you’re tracking down a bug and find that it was introduced by a single commit. Instead of manually going in, fixing it, and committing a new snapshot, you can use `git revert` to automatically do all of this for you.

![Git revert - Atlassian git tutorials](https://wac-cdn.atlassian.com/dam/jcr:b6fcf82b-5b15-4569-8f4f-a76454f9ca5b/03%20(7).svg?cdnVersion=649)
  
- **SYNOPSIS**
    ```shell
	git revert [--[no-]edit] [-n] [-m parent-number] [-s] [-S[<keyid>]] <commit>…
	git revert (--continue | --skip | --abort | --quit)
	```
- The `git revert` command is used for undoing changes to a repository's commit history. Other 'undo' commands like, `git checkout` and `git reset`, move the `HEAD` and branch ref pointers to a specified commit. `Git revert` also takes a specified commit, however, `git revert` does not move ref pointers to this commit. A revert operation will take the specified commit, inverse the changes from that commit, and create a new "revert commit". The ref pointers are then updated to point at the new revert commit making it the tip of the branch.
### <u style="color:#6DF053;">Git merge</u>
- `git merge` - Join two or more development histories together
- **SYNOPSIS**
	```shell
	git merge [-n] [--stat] [--no-commit] [--squash] [--[no-]edit]
			[--no-verify] [-s <strategy>] [-X <strategy-option>] [-S[<keyid>]]
			[--[no-]allow-unrelated-histories]
			[--[no-]rerere-autoupdate] [-m <msg>] [-F <file>]
			[--into-name <branch>] [<commit>…]
	git merge (--continue | --abort | --quit)
	```
- `git merge` command lets you take the independent lines of development created by `git branch` and integrate them into a single branch.
- `Git merge` will combine multiple sequences of commits into one unified history. In the most frequent use cases, `git merge` is used to combine two branches. The following examples in this document will focus on this branch merging pattern. In these scenarios, `git merge` takes two commit pointers, usually the branch tips, and will find a common base commit between them. Once Git finds a common base commit it will create a new "merge commit" that combines the changes of each queued merge commit sequence.

Say we have a new branch feature that is based off the `main` branch. We now want to merge this feature branch into `main`.

![](https://wac-cdn.atlassian.com/dam/jcr:7afd8460-b7bf-4c42-b997-4f5cf24f21e8/01%20Branch-2%20kopiera.png?cdnVersion=649)

Invoking this command will merge the specified branch feature into the current branch, we'll assume `main`. Git will determine the merge algorithm automatically (discussed below).

![New merge commit node](https://wac-cdn.atlassian.com/dam/jcr:c6db91c1-1343-4d45-8c93-bdba910b9506/02%20Branch-1%20kopiera.png?cdnVersion=649)

Merge commits are unique against other commits in the fact that they have two parent commits. When creating a merge commit Git will attempt to auto magically merge the separate histories for you. If Git encounters a piece of data that is changed in both histories it will be unable to automatically combine them. This scenario is a version control conflict and Git will need user intervention to continue.
### <u style="color:#6DF053;">Git push</u>
- `git push` - Update remote refs along with associated objects (upload local repository content to a remote repository)
- The `git push` command is used to upload local repository content to a remote repository. Pushing is how you transfer commits from your local repository to a remote repo. It's the counterpart to `git fetch`, but whereas fetching imports commits to local branches, pushing exports commits to remote branches. Remote branches are configured using the `git remote` command. Pushing has the potential to overwrite changes, caution should be taken when pushing.
- **SYNOPSIS**
	```shell
	 git push  [--all | --mirror | --tags] [--follow-tags] [--atomic] [-n | --dry-run] 
	[--receive-pack=<git-receive-pack>]
		 [--repo=<repository>] [-f | --force] [-d | --delete] [--prune] [-v | --verbose]
		 [-u | --set-upstream] [-o <string> | --push-option=<string>]
	     [--[no-]signed|--signed=(true|false|if-asked)]
	     [--force-with-lease[=<refname>[:<expect>]] [--force-if-includes]]
	     [--no-verify] [<repository> [<refspec>…​]]
	```
- `git push` is most commonly used to publish an upload local changes to a central repository. After a local repository has been modified a push is executed to share the modifications with remote team members.

![Using git push to publish changes](https://wac-cdn.atlassian.com/dam/jcr:0d181327-3fb0-44ec-9ab4-d6dea0fd406f/01%20Git%20push%20discussion.svg?cdnVersion=649)

The above diagram shows what happens when your local `main` has progressed past the central repository’s `main` and you publish changes by running `git push origin main`. Notice how `git push` is essentially the same as running `git merge main` from inside the remote repository.
### <u style="color:#6DF053;">Git pull</u>
- `git pull` - Fetch from and integrate with another repository or a local branch. `git push` incorporates changes from a remote repository into the current branch. If the current branch is behind the remote, then by default it will fast-forward the current branch to match the remote.
- **SYNOPSIS**
	```shell
	git pull [<options>] [<repository> [<refspec>…]]
	```
- `git pull` command first runs `git fetch` which downloads content from the specified remote repository. Then a `git merge` is executed to merge the remote content refs and heads into a new local merge commit. To better demonstrate the pull and merging process let us consider the following example. Assume we have a repository with a main branch and a remote origin.

![Main on remote origin vs main on repo](https://wac-cdn.atlassian.com/dam/jcr:63e58c34-b273-4e48-a6b1-6e3ba4d4a0ea/01%20bubble%20diagram-01.svg?cdnVersion=649)

In this scenario, `git pull` will download all the changes from the point where the local and main diverged. In this example, that point is E. `git pull` will fetch the diverged remote commits which are A-B-C. The pull process will then create a new local merge commit containing the content of the new diverged remote commits.

![Remote origin/main merged to local main](https://wac-cdn.atlassian.com/dam/jcr:0269bb2d-eb7f-43d8-80a2-8afa88d11eea/02%20bubble%20diagram-02.svg?cdnVersion=649)

In the above diagram, we can see the new commit H. This commit is a new merge commit that contains the contents of remote A-B-C commits and has a combined log message. This example is one of a few `git pull` merging strategies. A `--rebase` option can be passed to `git pull` to use a rebase merging strategy instead of a merge commit. The next example will demonstrate how a rebase pull works. Assume that we are at a starting point of our first diagram, and we have executed `git pull --rebase`.

![rebase](https://wac-cdn.atlassian.com/dam/jcr:d5633068-d448-4140-953e-2ab31553ce10/03%20bubble%20diagram-03-updated@2x%20kopiera.png?cdnVersion=649)

In this diagram, we can now see that a rebase pull does not create the new H commit. Instead, the rebase has copied the remote commits A--B--C and rewritten the local commits E--F--G to appear after them them in the local origin/main commit history.
### <u style="color:#6DF053;">Git fetch</u>
- `git fetch` command downloads commits, files, and refs from a remote repository into your local repo. Fetching is what you do when you want to see what everybody else has been working on. It’s similar to `svn update` in that it lets you see how the central history has progressed, but it doesn’t force you to actually merge the changes into your repository. Git isolates fetched content from existing local content; it has absolutely no effect on your local development work. Fetched content has to be explicitly checked out using the `git checkout` command. This makes fetching a safe way to review commits before integrating them with your local repository.
- **SYNOPSIS**
	```shell
	git fetch [<options>] [<repository> [<refspec>…]]
	git fetch [<options>] <group>
	git fetch --multiple [<options>] [(<repository> | <group>)…]
	git fetch --all [<options>]
	```
- To better understand how `git fetch` works let us discuss how Git organizes and stores commits. Behind the scenes, in the repository's `./.git/objects` directory, Git stores all commits, local and remote. Git keeps remote and local branch commits distinctly separate through the use of branch refs. The refs for local branches are stored in the `./.git/refs/heads/`. Executing the `git branch` command will output a list of the local branch refs. The following is an example of `git branch` output with some demo branch names.

	```css
	git branch
	main
	feature1
	debug2
	```

	Examining the contents of the `/.git/refs/heads/` directory would reveal similar output.

	```bash
	ls ./.git/refs/heads/
	main
	feature1
	debug2
	```

	Remote branches are just like local branches, except they map to commits from somebody else’s repository. Remote branches are prefixed by the remote they belong to so that you don’t mix them up with local branches. Like local branches, Git also has refs for remote branches. Remote branch refs live in the `./.git/refs/remotes/` directory. The next example code snippet shows the branches you might see after fetching a remote repo conveniently named remote-repo:

	```bash
	git branch -r
	# origin/main
	# origin/feature1
	# origin/debug2
	# remote-repo/main
	# remote-repo/other-feature
	```

	This output displays the local branches we had previously examined but now displays them prefixed with `origin/`. Additionally, we now see the remote branches prefixed with `remote-repo`. You can check out a remote branch just like a local one, but this puts you in a detached `HEAD` state (just like checking out an old commit). You can think of them as read-only branches. To view your remote branches, simply pass the `-r` flag to the `git branch` command.

	You can inspect remote branches with the usual `git checkout` and `git log` commands. If you approve the changes a remote branch contains, you can merge it into a local branch with a normal `git merge`. So, unlike SVN, synchronizing your local repository with a remote repository is actually a two-step process: fetch, then merge. The `git pull` command is a convenient shortcut for this process.