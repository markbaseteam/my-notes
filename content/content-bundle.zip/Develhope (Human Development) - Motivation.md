**What reasons lead you to start your journey in Develhope?**
Ans: To have the opportunity to land a job and to learn new things over what I have learned in the past as well as to frow my network of developers

**What would it mean for you to complete the course?**
Ans: That I have accomplished to learn what I feel needed to give me the ability that I have a strong portfolio to show future customers and employers

**What would happen if you did not succeed?**
Ans: I would still continue on learning new things, doing some freelance jobs and try to apply for jobs as programming is my passion

**What is the biggest obstacle you see along your path?
How would you deal with it?**
Ans: I believe it would be with not having the ability to show my full potntial in programming. How I would deal with it, is pretty much to try harder and harder until I get to my goal

Which part of you to show up, to glow (6 months assignment)